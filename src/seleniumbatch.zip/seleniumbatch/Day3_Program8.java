/*8.	Write a program to execute the matched case.*/
package seleniumbatch;

public class Day3_Program8 {

	public static void main(String[] args) {
		int a=10;

		switch(a)
		{

		case 10: System.out.println("Value of a is equal to 10");

				break;

		case 20: System.out.println("Value of a is not equal to 10");

				break;
	     }
	}
}


