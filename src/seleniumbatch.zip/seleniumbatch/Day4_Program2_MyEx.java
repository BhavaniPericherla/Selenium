package seleniumbatch;

public class Day4_Program2_MyEx {

	public static void main(String[] args) {
		        Day4_Program2_MyEx2 ob1= new Day4_Program2_MyEx2();
			    ob1.setempId1(0002);
				ob1.setempName1("Ramu");;
				ob1.setempAge1(27);
		
	            /*System.out.println("Employee Name: " + ob1.getempName1());
		        System.out.println("Employee Id: " + ob1.getempId1());
		        System.out.println("Employee Age: " + ob1.getempAge1());*/
	}

}
