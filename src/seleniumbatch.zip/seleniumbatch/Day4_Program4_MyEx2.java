package seleniumbatch;

class Day4_Program4_MyEx2 implements Day4_Program4_MyEx,Day4_Program4_MyEx1
{
	public void abstractM1()
	{
		System.out.println(a);
		// a++;   
		}
	public void abstractM2()
	{
		System.out.println(b);
		// b++;
	}
}
