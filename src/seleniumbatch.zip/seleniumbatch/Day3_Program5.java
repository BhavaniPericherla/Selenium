/*5.	Write a program to execute the block of code infinitely using for loop*/
package seleniumbatch;

public class Day3_Program5 {

	public static void main(String[] args) {
		for(;;)
		System.out.println("block of code infinitely using for loop");

	}

}
