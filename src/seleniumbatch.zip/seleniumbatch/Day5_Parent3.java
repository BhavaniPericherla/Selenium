package seleniumbatch;

class Day5_Parent3
{
	static int staticVar1= 1,staticVar2=2;
	
	void instm1()
	{
		System.out.println("Parent class instance methoid M1");
	}
	static void staticM1(){
		System.out.println("Parent class static methoid M1");
	}
	
}
