//Abstraction Class Example1 : 


package seleniumbatch;
public abstract class Day4_Program3_MyEx {
	int a=0;   // it act as instance variable
abstract void m1();
void m2() {
	
	System.out.println("Concrent method");
}
}
