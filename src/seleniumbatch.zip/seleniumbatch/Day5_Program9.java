/*9.	Write a program to prevent child or sub class creation for parent class.*/
package seleniumbatch;

final class parent
{
int a= 10;
public static void main(String[] args) 
{
	parent ob = new parent();
	System.out.println(ob.a);
}
}
public class Day5_Program9 extends parent
//final keyword will prevent child or sub class creation for parent class.
{
	
}
