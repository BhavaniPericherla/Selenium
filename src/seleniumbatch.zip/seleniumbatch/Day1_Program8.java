
package seleniumbatch;

public class Day1_Program8 {
	
	public static void m1(){
		
		System.out.println("Alphabets are: a,b,c,d.....z");
		
	}
	
	public static void m2(){
		
		System.out.println("Numerics are: 0,1,2,3,4,5,......");
		
	}
	
	public void instance1(){
		//Method8 mahi=new Method8();
		m1();
		m2();
		
	}
		public static void main(String args[]){
		
			Day1_Program8 ob1=new Day1_Program8();
			ob1.instance1();
			
		
	}


}
