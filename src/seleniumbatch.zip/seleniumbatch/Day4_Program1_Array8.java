//Java Program to demonstrate the way of passing an array  
//to method.  
package seleniumbatch;

public class Day4_Program1_Array8 {

}
