/*Write a program to declare two integer variables and two string variables in main method and print all the values in console.*/

package seleniumbatch;

public class Day1_Program1 {
public static void main(String[] args) 
{
	int a=10,b=20;
	String s1="Bhavani",s2="Ramu";

	System.out.println("Two integer variables are:");
	System.out.println("a="+a);
	System.out.println("b="+b);
	
	System.out.println("Two string variables are:");
	System.out.println("s1="+s1);
	System.out.println("s2="+s2);
	
}
}


	


