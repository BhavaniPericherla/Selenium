/*9.	Write a program to execute the code from matched case on words to till end.*/

package seleniumbatch;

public class Day3_Program9 {

	public static void main(String[] args) {
		String str = "Bhavani";

		switch (str)

		{ 

		case "Bhavani" : System.out.println("String contains bhavani"); 

		case "vani" : System.out.println("String contains vani"); 

		case "baby" : System.out.println("String contains baby");

		
		}


	}

}
