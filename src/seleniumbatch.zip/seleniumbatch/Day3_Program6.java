/*6.	Write a program to execute the block of code infinitely using while loop*/
package seleniumbatch;

public class Day3_Program6 {

	public static void main(String[] args) {
		while(true)
		{
			System.out.println("block of code infinitely using while loop");
		}
	}

}
