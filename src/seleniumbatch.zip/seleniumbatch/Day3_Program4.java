/*4.	Write a program to print even numbers from 1 to 50 using for loop.*/

package seleniumbatch;

public class Day3_Program4 {
public static void main(String[] args) {
	System.out.println("printing even numbers from 1 to 50 using for loop");
	for(int i=2;i<=50;i=i+2)
		System.out.println(i);
}
}
