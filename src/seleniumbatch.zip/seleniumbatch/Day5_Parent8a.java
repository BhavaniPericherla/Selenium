package seleniumbatch;
class Day5_Parent8a
{
	void instM1()
	{
	System.out.println("Parent class Method : instM1");
	}
	void instM2()
	{
	System.out.println("Parent class Method : instM2");
	}
}
