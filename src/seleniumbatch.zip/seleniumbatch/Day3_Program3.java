/*3.Write a program to print odd numbers from 1 to 100 using for loop.*/
package seleniumbatch;

public class Day3_Program3 {

	public static void main(String[] args) {
		System.out.println("printing odd numbers from 1 to 100 using for loop");
		for(int i=1;i<=100;i=i+2)
		System.out.println(i);
	}

}
