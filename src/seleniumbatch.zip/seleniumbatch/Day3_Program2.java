/*2.Declare and initialize three integers values a, b, c and print a statement when �b� greater than 
�a� and print some other statement when �a� greater than �c� and if both conditions are not matched 
then print some other statement*/

package seleniumbatch;

public class Day3_Program2 {
	public static void main(String[] args) {
	int a=30,b=40,c=10;
	if(b>a)
		System.out.println("Value of b: "+b);
	if(a>c)
		System.out.println("Value of a: "+a);
	else
		System.out.println("Value of c: "+a);
	}
}
