package seleniumbatch;
class Day5_Parent1
{
	void ParentM1(){
		System.out.println("Parent class instance methoid M1");
	}
	void ParentM2()
	{
		System.out.println("Parent class instance methoid M2");
	}
}