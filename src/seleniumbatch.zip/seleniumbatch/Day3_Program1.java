/*1.	Declare and initialize two integer values x, y and print one statement when �y� 
greater than �x� and if not print another statement.*/

package seleniumbatch;

public class Day3_Program1 {
    
	public static void main(String[] args) {
		
		int x=10,y=20;
		if(y>x)
			System.out.println("Value of Y:"+y);
		else
			System.out.println("Value of X"+x);

	}

}
