package seleniumbatch;

class Day5_Parent2
{
	int instVar1= 10,instVar2=20;
	void instM1(){
		System.out.println("Parent class instance methoid M1:"+instVar1);
	}
	void instM2()
	{
		System.out.println("Parent class instance methoid M2:"+instVar2);
	}
}
