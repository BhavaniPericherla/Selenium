/*7. Write a program for the following scenarios:
a. Add 4 string objects (ex: element1, element10, element3, element4) into one ArrayList
b. Add one more string object(ex: element5) in above ArrayList using ListIterator
c. Update the value "element10" with "element2" using ListIterator
d. Delete the value at last position using ListIterator*/

package seleniumbatch;

import java.security.acl.LastOwnerException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.ListIterator;

public class Day10_Program7 
{
public static void main(String[] args) 
{
	//a. Add 4 string objects (ex: element1, element10, element3, element4) into one ArrayList
	System.out.println("Option a:**************ss");
	ArrayList<String> ar = new ArrayList<String>(Arrays.asList("element1", "element10", "element3", "element4"));
	
    //b. Add one more string object(ex: element5) in above ArrayList using ListIterator
	System.out.println("Option b:**************");
	ListIterator<String> lsitr = ar.listIterator();
	lsitr.add("element5");
	System.out.println(ar);
	
	//c. Update the value "element10" with "element2" using ListIterator
	System.out.println("Option c:**************");
	int pos;
	for(int i=0;i<ar.size();i++)
	{
		pos= ar.indexOf("element10");
	    if(pos>=0)
		ar.set(pos,"element2");
		System.out.println(ar.get(i));
	}
	
	//d. Delete the value at last position using ListIterator
	System.out.println("Option d:**************");
	int i=0;
	
	ListIterator<String> li = ar.listIterator();
    while(li.hasNext()) 
    {
    	if(i<= ar.size())
        System.out.println(li.next()+" ");
    	i++;
    }
    
}


}
