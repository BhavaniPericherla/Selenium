/*7.	Write a program to print block of statements at least once even condition is not satisfied*/
package seleniumbatch;

public class Day3_Program7 {

	public static void main(String[] args) {
		int i=1;
		do{
			System.out.println("i="+i+2);
		}while(i<0);
	}
}
