package seleniumbatch;
interface Day4_Program4_MyEx1 {

int b=0;

abstract void abstractM2();
}