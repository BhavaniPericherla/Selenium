// Multiple inheritance by using interface in java

package seleniumbatch;

public interface Day4_Program4_MyEx 
{
  int a=0;   // By default variable a is public, static and final 
  abstract void abstractM1();
  void abstractM2();   // 2 programs contains the same method - abstractM2

}

