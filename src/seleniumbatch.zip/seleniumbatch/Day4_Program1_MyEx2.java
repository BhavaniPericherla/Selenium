package seleniumbatch;

public class Day4_Program1_MyEx2 {

	public static void main(String[] args) {
		Day4_Program1_MyEx ob1= new Day4_Program1_MyEx();
	/*ob1.setEmpId(0001);
		ob1.setEmpName("Bhavani");;
		ob1.setEmpAge(25);*/

		System.out.println("Employee Name: " + ob1.getEmpName());
        System.out.println("Employee Id: " + ob1.getEmpId());
        System.out.println("Employee Age: " + ob1.getEmpAge());

	}

}
